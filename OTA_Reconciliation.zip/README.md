
# OTA Reconciliation

This application is built using python 3.10.4. To run the application, you need to have a minimum python version of 3.10.1

[Download Python](https://www.python.org/downloads/release/python-3104/)
## Deployment

Deploy OTA Reconciliation Django Web Application

```bash
  git clone https://TC-IT-DEV@bitbucket.org/unizyr/ota-reconciliation-python.git
```
```bash  
  cd ota-reconciliation-python
```
```bash
  pip install -r requirements.txt
```
```bash
  python manage.py runserver
```
    